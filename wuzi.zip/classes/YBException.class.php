<?php
	/**
	 * 异常类
	 *
	 *
	 */
	class YBException extends Exception{
		
	}

?>