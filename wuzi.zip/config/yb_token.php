<?php
/**
 * 配置文件(轻应用)
 */
$config = array(
	'AppID' => 'e1e45b12b5944b50', //此处填写你的appid
	'AppSecret' => '80a41fdaba3b1729a4e541ce5b3d793b', //此处填写你的AppSecret
	'CallBack' => 'http://f.yiban.cn/iapp271598', //此处填写你的授权回调地址
);
// $config = array('AppID' => '216e4ceb7fac0891',
// 	'AppSecret' => 'c56c5256bdf6b38ef844b2661375ed6c',
// 	'CallBack' => 'http://f.yiban.cn/iapp200981',
// );