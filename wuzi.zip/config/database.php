<?php
$dsn = "mysql:dbname=bdm285551132_db;host=bdm285551132.my3w.com;port=3306";
$username = "bdm285551132";
$passwd = "54dudashen";
?>